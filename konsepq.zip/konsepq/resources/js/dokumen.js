function serialize(form) 
{ 
    var field, l, s = [];
    if (typeof form == 'object' && form.nodeName == "FORM") {
        var len = form.elements.length;
        for (var i=0; i<len; i++) {
            field = form.elements[i];
            if (field.name && !field.disabled && field.type != 'file' && field.type != 'reset' && field.type != 'submit' && field.type != 'button') {
                if (field.type == 'select-multiple') {
                    l = form.elements[i].options.length; 
                    for (var j=0; j<l; j++) {
                        if(field.options[j].selected)
                            s[s.length] = encodeURIComponent(field.name) + "=" + encodeURIComponent(field.options[j].value);
                    }
                } else if ((field.type != 'checkbox' && field.type != 'radio') || field.checked) {
                    s[s.length] = encodeURIComponent(field.name) + "=" + encodeURIComponent(field.value);
                }
            }
        }
    }
    return s.join('&').replace(/%20/g, '+');
}

function kirim_post(url)
{ 
	document.getElementById("loader").style='display:block' ;
	var xhr = new XMLHttpRequest();
	var data=serialize(frm_cetak);  
	xhr.open("POST",url, true); 
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	xhr.onreadystatechange = function() {//Call a function when the state changes.
		if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
			//document.getElementById("pesan_kirim").style="display.block" ;
			var str=xhr.responseText ;
			document.getElementById("loader").style='display:none' ; 
			document.getElementById("success").style='display:block' ;  
			var res = str.split("^");
			if(res[1])
			{
				document.getElementById("success").innerHTML=res[0];
				window.location.href =res[1];
			}else
			{
				document.getElementById("success").innerHTML=str;
			}
			
			
		}
	}
	xhr.send(data); 
}; 

function edit_isi(var_nomor, isi) 
{
    var xhr = new XMLHttpRequest();
	var perkara_id=document.getElementById('perkara_id').value;
	xhr.open("POST","_dokumen_update", true); 
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	xhr.onreadystatechange = function() {//Call a function when the state changes.
		if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200) {
			//document.getElementById("pesan_kirim").style="display.block" ;
			 
			 var pesan=xhr.responseText; 
			 
				 notifier.show('Pesan!', pesan, '', '',5000); 
			 
			 
			
			
		}
	}
	xhr.send("var_nomor="+var_nomor+"&DATA="+isi+"&perkara_id="+perkara_id); 
} 