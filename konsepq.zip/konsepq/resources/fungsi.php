<?php  
function convertToRomawi_backup($bulan){
		switch ($bulan) {
			case 1:
				$bulan='I';
			break;
			case 2:
				$bulan='II';
			break;
			case 3:
				$bulan='III';
			break;
			case 4:
				$bulan='IV';
			break;
			case 5 :
				$bulan='V';
			break;	
			case  6 :
				$bulan='VI';
			break;		
			case  7 :
				$bulan='VII';
			break;
			case  8 :
				$bulan='VIII';
			break;
			case  9 :
				$bulan='IX';
			break;	
			case  10 :
				$bulan='X';
			break;
			case  11 :
				$bulan='XI';
			break;
			case  12 :
				$bulan='XII';
			break;
		}
		return $bulan;
	}
if ( ! function_exists('antiInjections'))
{ 
	function antiInjections($string) 
	{
		$filter = stripslashes(strip_tags(htmlspecialchars($string,ENT_QUOTES)));
		$sql = array();$sql[0] = '/from/';$sql[1] = '/select/';$sql[2] = '/union/';$sql[3] = '/order/';$sql[4] = '/insert/';$sql[5] = '/delete/';$sql[6] = '/drop/';$sql[7] = '/tables/';$sql[8] = '/show/';$sql[9] = '/table/';$sql[9] = '/where/';
		$filter= preg_replace($sql, '', $filter);
		$filter = str_replace("table","",$filter);
		return $filter; 
	}
 }
 function getSelisihHari($date1,$date2){
	 	$date1 = strtotime($date1);
	 	$date2 = strtotime($date2);
	 	$datediff = $date2 - $date1;
	 	return floor($datediff/(60*60*24));
	}
function hasil_mediasi($hasil){
      switch ($hasil){
        case "Y":
          return "Berhasil";
          break;
        case "S":
          return "Berhasil Sebagian";
          break;
        case "T":
          return "Tidak Berhasil";
          break;
        case "D":
          return "Tidak Dapat Dilaksanakan";
          break;
        case " ":
          return " ";
          break;
        case NULL:
          return " ";
          break; 
    }
}     
    function pilihbulan($bln){
      switch ($bln){
        case "01":
          return "Januari";
          break;
        case "02":
          return "Pebruari";
          break;
        case "03":
          return "Maret";
          break;
        case "04":
          return "April";
          break;
        case "05":
          return "Mei";
          break;
        case "06":
          return "Juni";
          break;
        case "07":
          return "Juli";
          break;
        case "08":
          return "Agustus";
          break;
        case "09":
          return "September";
          break;
        case "10":
          return "Oktober";
          break;
        case "11":
          return "Nopember";
          break;
        case "12":
          return "Desember";
          break;
    }
}  
function tgl_dari_mysql($tgl){
      	if($tgl==null)
        {
          	$tgl='';
        }else
        {
            $pecah = explode("-", $tgl);
    		$tanggal = $pecah[2];
    		$bulan = $pecah[1];
    		$thn =  $pecah[0];
    		$tgl=$tanggal.'/'.$bulan.'/'.$thn;
        }
        return $tgl;
    
}   
function tgl_panjang_dari_mysql($tgl){
      	if($tgl==null)
        {
          	$tgl='';
        }else
        {
            $pecah = explode("-", $tgl);
    		$tanggal = $pecah[2];
    		$bulan = $pecah[1];
    		$thn =  $pecah[0];
    		$tgl=$tanggal.' '.pilihbulan($bulan).' '.$thn;
        }
        return $tgl;
    
} 


if ( ! function_exists('nama_hari'))
{
	function nama_hari($tanggal)
	{
		$ubah = gmdate($tanggal, time()+60*60*8);
		$pecah = explode("-",$ubah);
		$tgl = $pecah[2];
		$bln = $pecah[1];
		$thn = $pecah[0];

		$nama = date("l", mktime(0,0,0,$bln,$tgl,$thn));
		$nama_hari = "";
		if($nama=="Sunday") {$nama_hari="Minggu";}
		else if($nama=="Monday") {$nama_hari="Senin";}
		else if($nama=="Tuesday") {$nama_hari="Selasa";}
		else if($nama=="Wednesday") {$nama_hari="Rabu";}
		else if($nama=="Thursday") {$nama_hari="Kamis";}
		else if($nama=="Friday") {$nama_hari="Jumat";}
		else if($nama=="Saturday") {$nama_hari="Sabtu";}
		return $nama_hari;
	}
}
  
function tgl_panjang_indo($tgl){
      	if($tgl==null)
        {
          	$tgl='';
        }else
        {
            $pecah = explode("/", $tgl);
    		$tanggal = $pecah[0];
    		$bulan = @$pecah[1];
    		$thn =  @$pecah[2];
    		$tgl=$tanggal.' '.pilihbulan($bulan).' '.$thn;
        }
        return $tgl;
    
}   
function tgl_ke_mysql($tgl){
      	if($tgl==null)
        {
          	$tgl='';
        }else
        {
            $pecah = explode("/", $tgl);
    		$tanggal = $pecah[0];
    		$bulan = $pecah[1];
    		$thn =  $pecah[2];
    		$tgl=$thn.'-'.$bulan.'-'.$tanggal;
        }
        return $tgl;
    
}   
 	function lempar($url) {
    echo '<script language = "javascript">';
    echo 'window.location.href = "'.$url.'"';
    echo '</script>';
	}
	
 
    
function terbilang($bilangan)
{
    $angka = array('0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
        '0', '0', '0');
    $kata = array('', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh',
        'delapan', 'sembilan');
    $tingkat = array('', 'ribu', 'juta', 'milyar', 'triliun');

    $panjang_bilangan = strlen($bilangan);

    /* pengujian panjang bilangan */
    if ($panjang_bilangan > 15)
    {
        $kalimat = "Diluar Batas";
        return $kalimat;
    }

    /* mengambil angka-angka yang ada dalam bilangan,
    dimasukkan ke dalam array */
    for ($i = 1; $i <= $panjang_bilangan; $i++)
    {
        $angka[$i] = substr($bilangan, -($i), 1);
    }

    $i = 1;
    $j = 0;
    $kalimat = "";


    /* mulai proses iterasi terhadap array angka */
    while ($i <= $panjang_bilangan)
    {
        $subkalimat = "";
        $kata1 = "";
        $kata2 = "";
        $kata3 = "";

        /* untuk ratusan */
        if ($angka[$i + 2] != "0")
        {
            if ($angka[$i + 2] == "1")
            {
                $kata1 = "seratus";
            }
            else
            {
                $kata1 = $kata[$angka[$i + 2]] . " ratus";
            }
        }

        /* untuk puluhan atau belasan */
        if ($angka[$i + 1] != "0")
        {
            if ($angka[$i + 1] == "1")
            {
                if ($angka[$i] == "0")
                {
                    $kata2 = "sepuluh";
                }
                elseif ($angka[$i] == "1")
                {
                    $kata2 = "sebelas";
                }
                else
                {
                    $kata2 = $kata[$angka[$i]] . " belas";
                }
            }
            else
            {
                $kata2 = $kata[$angka[$i + 1]] . " puluh";
            }
        }

        /* untuk satuan */
        if ($angka[$i] != "0")
        {
            if ($angka[$i + 1] != "1")
            {
                $kata3 = $kata[$angka[$i]];
            }
        }

        /* pengujian angka apakah tidak nol semua,
        lalu ditambahkan tingkat */
        if (($angka[$i] != "0") or ($angka[$i + 1] != "0") or ($angka[$i + 2] != "0"))
        {
            $subkalimat = "$kata1 $kata2 $kata3 " . $tingkat[$j] . " ";
        }

        /* gabungkan variabe sub kalimat (untuk satu blok 3 angka)
        ke variabel kalimat */
        $kalimat = $subkalimat . $kalimat;
        $i = $i + 3;
        $j = $j + 1;

    }

    /* mengganti satu ribu jadi seribu jika diperlukan */
    if (($angka[5] == "0") and ($angka[6] == "0"))
    {
        $kalimat = str_replace("satu ribu", "seribu", $kalimat);
    }
    return trim($kalimat . "");
}
 

$input_bulan="";
$input_harian="";

 
 
?>