<div class="w3-center">
<div class="w3-bar">
  <a href="index" class="w3-bar-item w3-button w3-red">.:: Kembali </a>
  <a href="dokumen_blangko" class="w3-bar-item w3-button w3-green">Master Blangko</a>
  <a href="dokumen_variabel" class="w3-bar-item w3-button w3-purple">Master Variabel</a>
  <a href="dokumen_tanya_jawab"  class="w3-bar-item w3-button w3-teal">Tanya Jawab</a>
</div>
</div>