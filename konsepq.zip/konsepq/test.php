<?php 

$rtf=file_get_contents("http://raehman/sipp/slide_sidang");
echo $rtf;

?>