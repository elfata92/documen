 
		<ul>
			<li class="has-sub">
				<a href="index">Home</a> 
			</li>
			 
			
			<li class="has-sub"> <a title="Buku Kas Umum" href="buku_kas_umum">Buku Kas Umum</a></li>
			<li class="has-sub"> <a title="Buku Bantu" href="#">Buku Bantu</a>
				<ul> 
					<li class="has-sub"><a href="buku_bantu_bank">Bank</a> </li>
					<li class="has-sub"><a href="buku_bantu_kas_tunai">Kas Tunai</a> </li>
					<li class="has-sub"><a href="#">Jurnal Uang Panjar Biaya Perkara </a> 
						<ul>
							<li class="has-sub"><a href="jurnal_uang_panjar_biaya_pa?tingkat=gugatan">Jurnal Uang Panjar Biaya Perkara Gugatan</a> </li>
							<li class="has-sub"><a href="jurnal_uang_panjar_biaya_pa?tingkat=permohonan">Jurnal Uang Panjar Biaya Perkara Permohonan</a> </li>
							<li class="has-sub"><a href="jurnal_uang_panjar_biaya?tingkat=banding">Jurnal Uang Panjar Biaya Perkara Banding</a> </li>
							<li class="has-sub"><a href="jurnal_uang_panjar_biaya?tingkat=kasasi">Jurnal Uang Panjar Biaya Perkara Kasasi</a> </li>
							<li class="has-sub"><a href="jurnal_uang_panjar_biaya?tingkat=pk">Jurnal Uang Panjar Biaya Perkara Peninjauan Kembali</a> </li>
							<li class="has-sub"><a href="jurnal_uang_panjar_biaya?tingkat=eksekusi">Jurnal Uang Panjar Biaya Perkara Eksekusi</a> </li>
							<li class="has-sub"><a href="jurnal_uang_panjar_biaya?tingkat=konsignyasi">Jurnal Uang Panjar Biaya Perkara Konsignasi</a> </li>
						</ul>
						
					</li>
					<li class="has-sub"><a href="buku_bantu_konsignasi_bulanan">Uang Konsignasi</a> </li>
					<li class="has-sub"><a href="buku_bantu_eksekusi">Uang Eksekusi</a> </li>
					<li class="has-sub"><a href="buku_bantu_iwadl_bulanan">Uang Iwadl</a> </li>
					<li class="has-sub"><a title="Buku Bantu Biaya ATK/Proses Perkara" href="buku_bantu_biaya_atk">Biaya ATK/Proses Perkara</a> </li>
					<li class="has-sub"><a href="">Uang HHK dan HHKL</a> </li>
					<li class="has-sub"><a href="">Uang Perkara Belum Didaftar</a> </li>
					<li class="has-sub"><a title="Buku Bantu Persediaan Materai" href="buku_bantu_persediaan_materai">Persediaan Materai</a> </li>
					<li class="has-sub"><a href="#">Sisa Panjar</a> </li>
				</ul>		
			</li>
						 
			<li class="has-sub"> <a title="contoh" href="#">Laporan</a>
				<ul>
					<li class="has-sub"><a href="laporan_rekonsiliasi_uang_perkara">Laporan Rekonsiliasi Uang Perkara</a> </li>
					<li class="has-sub"><a href="#">L.1-PA.7</a> </li>
				</ul> 
				
			</li>
		
 
			<li class="has-sub">
				<a href="#">Tools</a>
					<ul>
						<li class="has-sub"> 
							<a href="#">Transaksi Keuangan Harian</a> 
							<ul>
								<li class="has-sub"><a href="keuangan_transaksi_harian">Transaksi Harian Beserta Rekap</a> </li>
								<li class="has-sub"><a href="transaksi_harian_sipp">Transaksi Harian</a> </li>
								<li class="has-sub"><a href="transaksi_panjar_harian">Transaksi Panjar</a> </li>
								<li class="has-sub"><a href="transaksi_pnbp_harian">Transaksi PNBP</a> </li>
								<li class="has-sub"><a href="transaksi_atk_harian">Transaksi ATK</a> </li>
								<li class="has-sub"><a href="transaksi_panggilan_harian">Transaksi Panggilan</a> </li>
								<li class="has-sub"><a href="transaksi_pemberitahuan_harian">Transaksi Pemberitahuan</a> </li>
								<li class="has-sub"><a href="transaksi_materai_harian">Transaksi Materai</a> </li>
								<li class="has-sub"><a href="transaksi_sisa_panjar_harian">Pengembalian Sisa Panjar</a> </li>
								<li class="has-sub"><a href="transaksi_hhk_harian">Hak-hak kepaniteraan</a> </li>
								<li class="has-sub"><a href="transaksi_hhk_harian_lainya">Hak-hak kepaniteraan Lainnya</a> </li>
								<li class="has-sub"><a href="transaksi_hhk_harian_lainya_baru">Hak-hak kepaniteraan Baru</a> </li>
							</ul>
						</li>
						<li class="has-sub"> <a href="keuangan_saldo_awal">Input Saldo Awal dan Transaksi Bank</a></li>
						<li class="has-sub"> <a href="#">Validasi Keuangan</a>
							<ul>
								<li class="has-sub"><a href="keuangan_valid_harian">Validasi Transaksi Harian</a> </li>
								<li class="has-sub"><a href="keuangan_valid_bulanan">Rekap Perbandingan bulanan</a> </li>
								<li class="has-sub"><a href="keuangan_valid_tahunan">Rekap Perbandingan Tahunan</a> </li>
							</ul>
						</li>				 
						<li class="has-sub"> 
							<a href="">Keadaan keuangan</a>
							<ul>
								<li class="has-sub"> <a href="keuangan_berjalan">Perkara Berjalan</a></li>
								<li class="has-sub"> <a href="">Perkara dalam upaya hukum </a>
									<ul>
									<li class="has-sub"> <a href="keuangan_banding">Banding</a></li>
									<li class="has-sub"> <a href="keuangan_kasasi">Kasasi</a></li>
									<li class="has-sub"> <a href="keuangan_pk">Peninjauan Kembali</a></li>
									</ul> 
								</li>
								<li class="has-sub"> <a href="keuangan_putus_saldo">Perkara Putus Bersaldo</a></li>
								<li class="has-sub"> <a href="keuangan_rekap">Rekap Keuangan</a></li>
							</ul> 
						</li>
						<li class="has-sub"> <a href="lipa7a">LIPA 7a </a></li>
					</ul> 
			</li>	
			<li class="has-sub">
				<a href="#">Setting	</a>
					<ul>
						<li class="has-sub"> <a title="Saldo Awal BKU" href="saldo_awal_bku">Saldo Awal BKU</a></li>
						<li class="has-sub"> <a title="Silahkan Langsung Ketik di Alamat " href="#">Database</a></li>
						<li class="has-sub"> <a href="setting_lain">Lain-lain</a></li>
					</ul> 
			</li>	
		</ul> 